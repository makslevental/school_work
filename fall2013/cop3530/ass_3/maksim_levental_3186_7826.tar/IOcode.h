
#include <iostream>
#include "Linearlist.h"

using namespace std;

void userInputOutput (linearList* l, string dataStructure);

