
#include <iostream>
#include "Chain.h"
#include "IOcode.h"

using namespace std;

int main (){

	chain *myChain = new chain(10);
	userInputOutput(myChain, "chain");
	delete myChain;
}
